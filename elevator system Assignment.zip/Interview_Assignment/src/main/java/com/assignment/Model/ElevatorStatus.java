package com.assignment.Model;

public class ElevatorStatus {
	int currentFloor;

	public int getCurrentFloor() {
		return currentFloor;
	}

	public void setCurrentFloor(int currentFloor) {
		this.currentFloor = currentFloor;
	}

	
}

